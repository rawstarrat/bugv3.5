module.exports = {
  BOT_TOKEN: "7609874976:AAEoDb_x7MhhQmrvJxiXpxmB3VD_cJJ9SnE", // Token bot Telegram
  OWNER_ID: ["7099464128"],
  allowedGroupIds: [-1002401306074, -1002361556670, -1002386380830, -1002415460020, -4514397992], // ID grup yang diizinkan
};